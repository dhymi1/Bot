#!/bin/bash
#
# Variables to be used for background styling.

# color
readonly BG_BROWN="\e[0;43m"
